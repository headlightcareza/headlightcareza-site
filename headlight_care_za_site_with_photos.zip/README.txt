
Headlight Care ZA - Website

Steps:
1) Replace before.jpg and after.jpg with real before/after photos of your work.
2) Upload this folder to GitHub Pages, Netlify, or Neocities to get a free live link for your bio.
3) All contact details are already filled in (WhatsApp link works with your number).

Guarantee: Included on site — 6 months free re-coat if headlights turn cloudy again.
